
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;


import aes.AES;

@WebServlet("/TextEnDe")
public class TextEnDe extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public TextEnDe() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // doGet logic
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action.equals("TextE")) {
            // Text Encryption Logic
            String plainText = request.getParameter("plainText");
            final String secretKey = request.getParameter("secretKey");
            String encryptedString = AES.encrypt(plainText, secretKey);
            
            RequestDispatcher rd;
			request.setAttribute("eText",encryptedString);
			request.setAttribute("pText",plainText);
			//request.setAttribute("sText",secretKey);
			rd=request.getRequestDispatcher("TextEncDec.jsp");
			rd.forward(request, response);
			

            Connection con = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3030/encdec", "root", "root");
                PreparedStatement pst = con.prepareStatement("INSERT INTO texte (email, `key`, plaintext, date_time) VALUES (?, ?, ?, ?)");

                pst.setString(1, request.getParameter("email"));
                pst.setString(2, request.getParameter("secretKey"));
                pst.setString(3, request.getParameter("plainText"));
                pst.setString(4, request.getParameter("datetime"));

                int rowCount = pst.executeUpdate();

                RequestDispatcher dispatcher = request.getRequestDispatcher("TextEncDec.jsp");
                if (rowCount > 0) {
                    request.setAttribute("status", "success");
                } else {
                    request.setAttribute("status", "failed");
                }
                dispatcher.forward(request, response);
               
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("status", "failed");
                RequestDispatcher dispatcher = request.getRequestDispatcher("TextEncDec.jsp");
                dispatcher.forward(request, response);
                
            } finally {
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
           
        } else if(action.equals("TextD")) {
            // Text Decryption Logic (to be implemented)
        	String secKey = request.getParameter("secKey");
            String encText = request.getParameter("encText");
            String decryptedString = AES.decrypt(encText, secKey);

            RequestDispatcher rd;
           // request.setAttribute("secKey", secKey);
            request.setAttribute("encText", encText);
            request.setAttribute("decryptedString", decryptedString);
            rd = request.getRequestDispatcher("TextEncDec.jsp");
            rd.forward(request, response);
            

            Connection con = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3030/encdec", "root", "root");
                PreparedStatement pst = con.prepareStatement("INSERT INTO textd (email, `key`, ciphertext, date_time) VALUES (?, ?, ?, ?)");

                pst.setString(1, request.getParameter("email2"));
                pst.setString(2, request.getParameter("secKey"));
                pst.setString(3, request.getParameter("encText"));
                pst.setString(4, request.getParameter("datetime2"));

                int rowCount = pst.executeUpdate();

                RequestDispatcher dispatcher = request.getRequestDispatcher("TextEncDec.jsp");
                if (rowCount > 0) {
                    request.setAttribute("status", "success");
                } else {
                    request.setAttribute("status", "failed");
                }
                dispatcher.forward(request, response);
                
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("status", "failed");
                RequestDispatcher dispatcher = request.getRequestDispatcher("TextEncDec.jsp");
                dispatcher.forward(request, response);
                
            } finally {
                try {
                    if (con != null) {
                        con.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
           
        } 
        else {
            // Handle an unrecognized or undefined action (e.g., default or error scenario)
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
           
        }
        

    }
   
}

