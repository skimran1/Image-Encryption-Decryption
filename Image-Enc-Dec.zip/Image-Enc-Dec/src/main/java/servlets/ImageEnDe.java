package servlets;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import aes.ImageEnc;

@WebServlet("/ImageEnDe")
@MultipartConfig
public class ImageEnDe extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("imageEncDec.jsp");
        String action = request.getParameter("action");

        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3030/encdec", "root", "root");

            if (action.equals("imageE")) {
                String seKey = request.getParameter("seKey");
                Part part = request.getPart("image");
                String imageFileName = part.getSubmittedFileName();
                String path = "C:/Users/SHREE/Desktop/MyFolder/" + imageFileName;
                ImageEnc.EncryptImage(path, seKey);
                request.setAttribute("resultEnc", "Selected Image Encrypted Successfully");

                PreparedStatement pst = con.prepareStatement("INSERT INTO imagee (email, `secret_key`, image, date_time) VALUES (?, ?, ?, ?)");

                pst.setString(1, request.getParameter("email"));
                pst.setString(2, request.getParameter("seKey"));
                pst.setBlob(3, part.getInputStream()); // Set the image data as a blob
                pst.setString(4, request.getParameter("datetime"));

                int rowCount = pst.executeUpdate();

                if (rowCount > 0) {
                    request.setAttribute("status", "success");
                } else {
                    request.setAttribute("status", "failed");
                }
            } else if (action.equals("imageD")) {
                String deKey = request.getParameter("sdKey");
                Part part = request.getPart("image");
                String imageFileName = part.getSubmittedFileName();
                String path = "C:/Users/SHREE/Desktop/EncDecImages/" + imageFileName;
                ImageEnc.DecryptImage(path, deKey);
                request.setAttribute("resultDec", "Selected Image Decrypted Successfully");

                PreparedStatement pst = con.prepareStatement("INSERT INTO imaged (email, `secret_key`, image_data, date_time) VALUES (?, ?, ?, ?)");

                pst.setString(1, request.getParameter("email"));
                pst.setString(2, request.getParameter("sdKey"));
                pst.setString(3, imageFileName);
                pst.setString(4, request.getParameter("datetime"));

                int rowCount = pst.executeUpdate();

                if (rowCount > 0) {
                    request.setAttribute("status", "success");
                } else {
                    request.setAttribute("status", "failed");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("status", "failed");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        rd.forward(request, response);
    }
}
