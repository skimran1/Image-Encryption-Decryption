package retrivedata;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/UserCountServlet")
public class UserCountServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int totalUsers = getTotalUserCountFromDB();
        request.setAttribute("totalUsers", totalUsers);
        RequestDispatcher dispatcher = request.getRequestDispatcher("adminindex.jsp");
        dispatcher.forward(request, response);
    }

    private int getTotalUserCountFromDB() {
        int userCount = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3030/encdec", "root", "root");

            PreparedStatement stmt = con.prepareStatement("SELECT COUNT(*) FROM register");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            userCount = rs.getInt(1);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userCount;
    }
}
